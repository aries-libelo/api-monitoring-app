sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("com.sap.cep.apimonitoringapp.apimonitorui.controller.App", {
      onInit() {
      }
  });
});