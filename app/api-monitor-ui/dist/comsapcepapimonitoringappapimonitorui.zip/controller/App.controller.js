sap.ui.define(["sap/ui/core/mvc/Controller"],i=>{"use strict";return i.extend("com.sap.cep.apimonitoringapp.apimonitorui.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map